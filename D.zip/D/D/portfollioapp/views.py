from django.shortcuts import render
from portfollioapp.models import Education, Experience

# Create your views here.

def home(request):
    return render(request, 'home.html')

def about(request):
    education = Education.objects.all()
    experience = Experience.objects.all()
    context = {
        'educations': education,
        'experiences': experience,
    }
    
    return render(request, 'about.html', context=context)

def contract(request):
    return render(request, 'contract.html')

