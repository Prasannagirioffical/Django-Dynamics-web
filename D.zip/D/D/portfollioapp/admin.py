from django.contrib import admin
from portfollioapp.models import Education, Experience   #or write * to add all from models.py
# Register your models here.

admin.site.register(Education)
admin.site.register(Experience)

